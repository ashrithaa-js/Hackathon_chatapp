import os
from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from encryption import encrypt_message, decrypt_message
from models import db, User, Message
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///chat.db'
app.config['JWT_SECRET_KEY'] = 'supersecretkey'
app.config['UPLOAD_FOLDER'] = 'uploads'
db.init_app(app)
jwt = JWTManager(app)

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# -------- AUTH ROUTES --------
@app.route('/auth/register', methods=['POST'])
def register():
    data = request.get_json()
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'message': 'User already exists'}), 400
    new_user = User(username=data['username'], password=data['password'])
    db.session.add(new_user)
    db.session.commit()
    return jsonify({'message': 'User registered successfully'})

@app.route('/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    user = User.query.filter_by(username=data['username'], password=data['password']).first()
    if user:
        token = create_access_token(identity=user.username)
        return jsonify({'token': token})
    return jsonify({'message': 'Invalid credentials'}), 401

# -------- MESSAGING ROUTES --------
@app.route('/chat/send', methods=['POST'])
@jwt_required()
def send_message():
    data = request.get_json()
    encrypted_msg = encrypt_message(data['message'])
    new_msg = Message(sender=get_jwt_identity(), receiver=data['receiver'], content=encrypted_msg)
    db.session.add(new_msg)
    db.session.commit()
    return jsonify({'message': 'Message sent'})

@app.route('/chat/messages', methods=['GET'])
@jwt_required()
def get_messages():
    messages = Message.query.filter_by(receiver=get_jwt_identity()).all()
    decrypted_messages = [{'sender': msg.sender, 'message': decrypt_message(msg.content)} for msg in messages]
    return jsonify(decrypted_messages)

# -------- FILE UPLOAD ROUTES --------
@app.route('/file/upload', methods=['POST'])
@jwt_required()
def upload_file():
    file = request.files['file']
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
    file.save(file_path)
    return jsonify({'message': 'File uploaded'})

@app.route('/file/files', methods=['GET'])
@jwt_required()
def list_files():
    return jsonify({'files': os.listdir(app.config['UPLOAD_FOLDER'])})

# -------- FRONTEND ROUTE --------
@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
